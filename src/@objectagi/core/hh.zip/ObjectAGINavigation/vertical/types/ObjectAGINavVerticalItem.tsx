'use client';
import NavLinkAdapter from '@objectagi/core/NavLinkAdapter';
import { alpha, styled } from '@mui/material/styles';
import ListItemText from '@mui/material/ListItemText';
import clsx from 'clsx';
import { useMemo } from 'react';
import { ListItemButton, ListItemButtonProps } from '@mui/material';
import ObjectAGINavBadge from '../../ObjectAGINavBadge';
import ObjectAGISvgIcon from '../../../ObjectAGISvgIcon';
import { ObjectAGINavItemComponentProps } from '../../ObjectAGINavItem';

type ListItemButtonStyleProps = ListItemButtonProps & {
  itempadding: number;
};

const Root = styled(ListItemButton)<ListItemButtonStyleProps>(({ theme, ...props }) => ({
  minHeight: 36,
  width: '100%',
  borderRadius: '8px',
  margin: '0 0 4px 0',
  paddingRight: 16,
  paddingLeft: props.itempadding > 80 ? 80 : props.itempadding,
  paddingTop: 10,
  paddingBottom: 10,
  color: alpha(theme.palette.text.primary, 0.7),
  cursor: 'pointer',
  textDecoration: 'none!important',
  '&:hover': {
    color: theme.palette.text.primary
  },
  '&.active': {
    color: theme.palette.text.primary,
    backgroundColor:
      theme.palette.mode === 'light' ? 'rgba(0, 0, 0, .05)!important' : 'rgba(255, 255, 255, .1)!important',
    transition: 'border-radius .15s cubic-bezier(0.4,0.0,0.2,1)',
    '& > .objectagi-list-item-text-primary': {
      color: 'inherit'
    },
    '& > .objectagi-list-item-icon': {
      color: '#000000 !important'
    }
  },
  '& > .objectagi-list-item-icon': {
    marginRight: 16,
    color: '#000000 !important'
  },
  '& > .objectagi-list-item-text': {}
}));

function ObjectAGINavVerticalItem(props: ObjectAGINavItemComponentProps) {
  const { item, nestedLevel = 0, onItemClick, checkPermission } = props;
  const itempadding = nestedLevel > 0 ? 38 + nestedLevel * 16 : 16;
  const component = item.url ? NavLinkAdapter : 'li';

  const itemProps = useMemo(
    () => ({
      ...(component !== 'li' && {
        disabled: item.disabled,
        to: item.url || '',
        end: item.end,
        role: 'button',
        exact: item?.exact
      })
    }),
    [item, component]
  );

  const memoizedContent = useMemo(
    () => (
      <Root
        component={component}
        className={clsx('objectagi-list-item', item.active && 'active')}
        onClick={() => onItemClick && onItemClick(item)}
        itempadding={itempadding}
        sx={item.sx}
        {...itemProps}
      >
        {item.icon && (
          <ObjectAGISvgIcon
            className={clsx('objectagi-list-item-icon shrink-0 force-dark-icon', item.iconClass)}
            sx={{ color: '#000000 !important', fill: '#000000 !important', stroke: '#000000 !important' }}
          >
            {item.icon}
          </ObjectAGISvgIcon>
        )}

        <ListItemText
          className="objectagi-list-item-text"
          primary={item.title}
          secondary={item.subtitle}
          classes={{
            // Increased font size for the main title
            primary: 'text-lg font-medium objectagi-list-item-text-primary truncate', 
            // Optional: also increase subtitle size if needed
            secondary: 'text-base font-medium objectagi-list-item-text-secondary leading-[1.5] truncate'
          }}
        />
        {item.badge && <ObjectAGINavBadge badge={item.badge} />}
      </Root>
    ),
    [component, item, itemProps, itempadding, onItemClick]
  );

  if (checkPermission && !item?.hasPermission) {
    return null;
  }

  return memoizedContent;
}

const NavVerticalItem = ObjectAGINavVerticalItem;

export default NavVerticalItem;