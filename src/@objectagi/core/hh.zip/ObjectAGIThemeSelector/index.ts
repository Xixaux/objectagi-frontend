export { default } from './ObjectAGIThemeSelector';
