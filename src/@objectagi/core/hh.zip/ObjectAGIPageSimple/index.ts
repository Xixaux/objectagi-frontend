export { default } from './ObjectAGIPageSimple';
