export { default } from './ObjectAGIScrollbars';
