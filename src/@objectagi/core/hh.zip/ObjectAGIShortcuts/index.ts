export { default } from './ObjectAGIShortcuts';
