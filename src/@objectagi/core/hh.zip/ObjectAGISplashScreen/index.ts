export { default } from './ObjectAGISplashScreen';
