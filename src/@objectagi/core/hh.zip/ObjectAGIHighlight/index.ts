export { default } from './ObjectAGIHighlight';
