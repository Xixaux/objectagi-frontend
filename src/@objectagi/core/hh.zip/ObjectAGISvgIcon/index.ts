export { default } from './ObjectAGISvgIcon';
