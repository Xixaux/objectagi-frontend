export { default } from './ObjectAGITheme';
