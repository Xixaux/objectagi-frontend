export { default } from './ObjectAGIPageCarded';
