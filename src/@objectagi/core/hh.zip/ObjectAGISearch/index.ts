export { default } from './ObjectAGISearch';
