export { default } from './ObjectAGISuspense';
