export { default } from './ObjectAGISettings';
