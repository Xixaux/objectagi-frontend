export { default } from './ObjectAGIExample';
