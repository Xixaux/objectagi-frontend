export { default } from './ObjectAGISidePanel';
