export { default } from './ObjectAGILoading';
